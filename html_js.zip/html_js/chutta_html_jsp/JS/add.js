 function func(no1,no2)
  {
   
   
    var sum = no1 +  no2;
    // alert(sum);
     
     return sum;
  }
  